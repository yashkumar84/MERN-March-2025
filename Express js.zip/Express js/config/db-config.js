export const dbCofig = {
  MONGO_URI: process.env.MONGO_URI,
};
