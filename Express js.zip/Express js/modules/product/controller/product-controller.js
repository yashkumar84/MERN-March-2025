import { addProductService } from "../service/product-service.js";

export const addProductController = (req, res) => {
  try {
    const product = addProductService(req, res);
    res.status(201).json({ message: "Product add Success", product: product });
  } catch (err) {
    res.status(501).json({ message: "Error While Add Product" + err });
  }
};
