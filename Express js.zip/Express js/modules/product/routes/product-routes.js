import { Router } from "express";
import { addProductController } from "../controller/product-controller.js";

export const productRouter = Router();

productRouter.post("/", addProductController);
