import { v4 as uuidv4 } from "uuid";
import { Product } from "../../../db/schema/Product.js";

export const addProductService = async (req, res) => {
  const {
    title,
    image,
    description,
    brand,
    model,
    color,
    category,
    price,
    discount,
  } = req.body;
  const productId = uuidv4();
  let newProduct;
  try {
    newProduct = new Product({
      brand: brand,
      category: category,
      color: color,
      description: description,
      discount: discount,
      id: productId,
      image: image,
      model: model,
      price: price,
      title: title,
    });

    await newProduct.save();
  } catch (err) {
    throw new Error("Error in Saving Product" + err);
  }

  return newProduct;
};
