import { User } from "../../../db/schema/User.js";
import { v4 as uuidv4 } from "uuid";
import { createHashPassword } from "../utils/password-utils.js";
import { loginService } from "../services/auth-service.js";

export const registerController = async (req, res) => {
  const { email, userName, password, phone, role } = req.body;
  const user = await User.findOne({ email });
  if (user) {
    res.status(501).json({ message: "User Already Exists" });
    return;
  }

  const userId = uuidv4();
  let hashedPassword;
  try {
    hashedPassword = createHashPassword(password);
  } catch (err) {
    res.status(500).json({ message: "Error Occurs" + err });
    return;
  }

  const newUser = new User({
    userId: userId,
    userName: userName,
    password: hashedPassword,
    email: email,
    role: role || "User",
    phone: phone,
  });

  try {
    await newUser.save();
  } catch (err) {
    res.status(501).json({ message: "Error In Register User" });
    return;
  }

  res
    .status(201)
    .json({ message: "User Registered Successfully", user: newUser });
};

export const loginController = async (req, res) => {
  try {
    const user = await loginService(req, res);
    res.status(200).json({ message: "User Login Successfull", user: user });
  } catch (err) {
    res.status(501).json({ message: err });
  }
};
