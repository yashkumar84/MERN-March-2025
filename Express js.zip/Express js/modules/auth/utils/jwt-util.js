import jwt from "jsonwebtoken";

export const genrateToken = (userId, email) => {
  const token = jwt.sign({ email, userId }, process.env.JWT_SECRET, {
    expiresIn: "1h",
  });

  return token;
};

export const verifyToken = (token) => {
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  return decoded;
};
