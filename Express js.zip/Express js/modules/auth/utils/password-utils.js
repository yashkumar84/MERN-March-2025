import bcrypt from "bcrypt";

export const createHashPassword = (plainPassword) => {
  try {
    const hashed = bcrypt.hashSync(plainPassword, parseInt(process.env.SALT));
    return hashed;
  } catch (err) {
    throw new Error(err);
  }
};

export const comparePassword = (plainPassword, hashedPassword) => {
  const isMatched = bcrypt.compareSync(plainPassword, hashedPassword);
  return isMatched;
};
