import { verifyToken } from "../utils/jwt-util.js";

export const authMiddleWare = (req, res, next) => {
  const token = req.headers["authorization"].split(" ")[1];
  if (!token) {
    res.status(501).json({ message: "Not Authenticated" });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    res.status(501).json({ message: "Not Verified User Login Again " });
  }
  req.user = decoded;
  next();
};

export const authorizationMiddleware = () => {
    
};
