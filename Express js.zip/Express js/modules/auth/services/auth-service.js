import { User } from "../../../db/schema/User.js";
import { genrateToken } from "../utils/jwt-util.js";
import { comparePassword } from "../utils/password-utils.js";

export const loginService = async (req, res) => {
  const { email, password, phone } = req.body;
  let user = await User.findOne({ email });

  if (!user) {
    throw new Error("User doesn't Exist Please Register");
  }

  const isMatched = comparePassword(password, user.password);
  if (!isMatched) {
    throw new Error("Invalid Email or Password");
  }

  const token = genrateToken(user.userId, user.email);

  return { user: user, token: token };
};
