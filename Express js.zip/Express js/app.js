import express from "express";
import { authRouter } from "./modules/auth/routes/authRoutes.js";
import { productRouter } from "./modules/product/routes/product-routes.js";

export const app = express();

app.use(express.json());
app.use("/v1/auth", authRouter);
app.use("/v1/product", productRouter);
app.get("/", (req, res) => {
  res.send("hello Dear this is My Website Welcome");
});
