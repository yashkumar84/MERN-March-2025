import dotenv from "dotenv";
import { app } from "./app.js";
import { createConnection } from "./db/connection.js";

dotenv.config();

app.listen(1234, () => {
  console.log("Application is Running on PORT 1234");
  createConnection();
});
