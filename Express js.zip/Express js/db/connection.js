import mongoose from "mongoose";

export async function createConnection() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connection Created");
  } catch (err) {
    console.log(err);
  }
}
