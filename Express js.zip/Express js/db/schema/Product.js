import mongoose from "mongoose";

//  {
//     id: 1,
//     title: "Sony WH-1000XM3...",
//     image: "https://storage...",
//     price: 773,
//     description: "Industry leading Active Noise...",
//     brand: "sony",
//     model: "WH-1000XM3",
//     color: "silver",
//     category: "audio",
//     discount: 11
//   },

const productSchema = new mongoose.Schema({
  id: { type: String, required: true },
  title: { type: String },
  image: { type: String },
  price: { type: Number },
  description: { type: String },
  brand: { type: String },
  color: { type: String },
  category: { type: String },
  discount: { type: Number },
  model: { type: String },
});

export const Product = mongoose.model("products", productSchema);
