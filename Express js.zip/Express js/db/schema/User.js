import mongoose, { SchemaType } from "mongoose";

const userSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  userName: { type: mongoose.SchemaTypes.String, required: true },
  email: { type: String, required: true },
  phone: { type: Number },
  role: {
    type: String,
    required: true,
    default: "User",
    enum: ["User", "Admin", "Seller"],
  },
  password: { type: String, required: true },
});

export const User = mongoose.model("users", userSchema);
