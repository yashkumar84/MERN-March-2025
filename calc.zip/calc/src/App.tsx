import Calc from "./pages/Calc";

function App() {
  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
          overflow: "hidden",
        }}
        className="calc"
      >
        <Calc />
      </div>
    </>
  );
}

export default App;
