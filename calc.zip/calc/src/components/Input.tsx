import "./css/Input.css";

type PropsType = {
  text: string;
};

const Input = ({ text }: PropsType) => {
  return (
    <div>
      <input className="input" type="text" value={text} />
    </div>
  );
};

export default Input;
