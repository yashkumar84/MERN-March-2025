import "./css/Button.css";

type PropsType = {
  text: string;
  fn: (value: string) => void;
};

const Button = ({ text, fn }: PropsType) => {
  return (
    <div>
      <button onClick={() => fn(text)} className="btn">
        {text}
      </button>
    </div>
  );
};

export default Button;
