import { useState } from "react";
import Button from "../components/Button";
import Input from "../components/Input";
import "./css/Calc.css";

const Calc = () => {
  const [text, setText] = useState("");

  const takeInput = (value: String) => {
    setText(text + value);
  };

  const evaluate = () => {
    setText(eval(text));
  };

  const allClear = () => {
    setText("");
  };

  const deleteFromLast = () => {
    setText(text.substring(0, text.length - 1));
  };
  return (
    <>
      <div className="container">
        <div className="input">
          <Input text={text} />
        </div>
        <div className="row">
          <Button text="AC" fn={allClear} />
          <Button text="(" fn={takeInput} />
          <Button text=")" fn={takeInput} />
          <Button text="<-" fn={deleteFromLast} />
        </div>

        <div className="row">
          <Button text="7" fn={takeInput} />
          <Button text="8" fn={takeInput} />
          <Button text="9" fn={takeInput} />
          <Button text="*" fn={takeInput} />
        </div>
        <div className="row">
          <Button text="4" fn={takeInput} />
          <Button text="5" fn={takeInput} />
          <Button text="6" fn={takeInput} />
          <Button text="-" fn={takeInput} />
        </div>
        <div className="row">
          <Button text="1" fn={takeInput} />
          <Button text="2" fn={takeInput} />
          <Button text="3" fn={takeInput} />
          <Button text="+" fn={takeInput} />
        </div>
        <div className="row">
          <Button text="0" fn={takeInput} />
          <Button text="." fn={takeInput} />
          <Button text="=" fn={evaluate} />
          <Button text="/" fn={takeInput} />
        </div>
      </div>
    </>
  );
};

export default Calc;
