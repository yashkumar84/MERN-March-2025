import "./css/Button.css"


interface PropsType {
  text: string;
}

const Button = (props: PropsType) => {
  return <button className="btn">{props.text}</button>;
};

export default Button;
