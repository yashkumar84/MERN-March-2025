import "./css/Button.css";

interface PropsType {
  text: string;
  func: () => void;
}

const Button = (props: PropsType) => {
  return (
    <button onClick={props.func} className="btn">
      {props.text}
    </button>
  );
};

export default Button;
