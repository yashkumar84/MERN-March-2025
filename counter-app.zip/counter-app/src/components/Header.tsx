const Header = () => {
  return (
    <>
      <h1 className="header">Counter App</h1>
    </>
  );
};

export default Header;
