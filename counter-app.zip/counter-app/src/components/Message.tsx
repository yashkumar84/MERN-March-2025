import "./css/Message.css";

interface PropsType {
  count: number;
}

const Message = (props: PropsType) => {
  return <h1 className="message">{props.count}</h1>;
};

export default Message;
