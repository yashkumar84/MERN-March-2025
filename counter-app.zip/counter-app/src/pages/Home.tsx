import Button from "../components/Button";
import Header from "../components/Header";
import Message from "../components/Message";

const Home = () => {
  let count = 1;
  return (
    <>
      <Header />

      <Message count={count} />
      <Button text="-" />
      <Button text="+" />
    </>
  );
};

export default Home;
