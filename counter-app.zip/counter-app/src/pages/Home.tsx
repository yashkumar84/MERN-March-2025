import { useState } from "react";
import Button from "../components/Button";
import Header from "../components/Header";
import Message from "../components/Message";
import "./css/Home.css";

const Home = () => {
  const [count, setCount] = useState(0);

  const dec = () => {
    setCount(count - 1);
    console.log(count);
  };

  const inc = () => {
    setCount(count + 1);
    console.log(count);
  };

  console.log(count);

  return (
    <>
      <Header />

      <Message count={count} />
      <Button text="-" func={dec} />
      <Button text="+" func={inc} />
    </>
  );
};

export default Home;
