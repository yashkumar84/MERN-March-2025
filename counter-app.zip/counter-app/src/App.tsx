import "./App.css";
import Home from "./pages/Home";

function App() {
  console.log("Hello");
  return (
    <>
      <Home/>
    </>
  );
}

export default App;
