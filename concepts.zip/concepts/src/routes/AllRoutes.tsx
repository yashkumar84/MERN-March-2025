import { useRoutes } from "react-router-dom";
import Home from "../pages/Home";
import About from "../pages/About";
import ContactPage from "../pages/ContactPage";
import LoginPage from "../pages/LoginPage";
import ProtectedRoute from "./ProtectedRoutes";
import DashBoard from "../pages/DashBoard";
import Settings from "../pages/Settings";

const AllRoutes = () => {
  return useRoutes([
    { path: "/", element: <Home /> },
    { path: "/about", element: <About /> },
    { path: "/contact", element: <ContactPage /> },
    { path: "/login", element: <LoginPage /> },
    {
      path: "/dashboard",
      element: (
        <ProtectedRoute>
          <DashBoard />
        </ProtectedRoute>
      ),
      children: [{ path: "/dashboard/settings", element: <Settings /> }],
    },
  ]);
};

export default AllRoutes;
