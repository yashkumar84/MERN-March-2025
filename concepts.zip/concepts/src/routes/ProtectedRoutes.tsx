import type React from "react";
import { useState, type JSX, type ReactNode } from "react";
import { Navigate, useNavigate } from "react-router-dom";

interface PropsType {
  children: ReactNode;
}

const ProtectedRoute = ({ children }: PropsType) => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();
  if (!isLogin) {
    return <Navigate to={"/login"} replace />;
  }
  return children;
};

export default ProtectedRoute;
