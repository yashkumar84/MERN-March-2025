const LoginPage = () => {
  return <div>Login Page</div>;
};

export default LoginPage;
