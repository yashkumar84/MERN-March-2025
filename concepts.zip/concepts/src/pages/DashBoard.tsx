import { Link, Outlet } from "react-router-dom";

const DashBoard = () => {
  return (
    <div>
      DashBoard Page
      <br />
      <Link to={"settings"}>Settings</Link>
      <Outlet />
    </div>
  );
};

export default DashBoard;
