import { useState } from "react";
import "./App.css";
import { Link, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import ContactPage from "./pages/ContactPage";
import DashBoard from "./pages/DashBoard";
import LoginPage from "./pages/LoginPage";
import ProtectedRoute from "./routes/ProtectedRoutes";
import Settings from "./pages/Settings";
import AllRoutes from "./routes/AllRoutes";

function App() {
  const [isLogin, setIsLogin] = useState<boolean>(true);
  const [students, setStudents] = useState<string[]>([
    "Yash",
    "Vivek",
    "Anand",
    "Jyoti",
    "Sakshi",
    "Kunal",
    "Muntazim",
    "Golu",
  ]);
  return (
    // <>
    //   {isLogin ? <h1>Welcome User </h1> : <h1>User Not Logged In</h1>}
    //   {isLogin && <h1>This is Profile Picture</h1>}

    //   {students.map((name: string, index) => (
    //     <h1 key={index}>{name}</h1>
    //   ))}
    // </>
    <>
      <div>
        <Link to={"about"}>About</Link>
        <Link to={"contact"}>Contact</Link>
        <Link to={"dashboard"}>DashBoard</Link>
      </div>
      {/* <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashBoard />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard/settings" element={<Settings />} />
        </Route>
        <Route path="/login" element={<LoginPage />} />
      </Routes> */}
      <AllRoutes />
    </>
  );
}

export default App;
