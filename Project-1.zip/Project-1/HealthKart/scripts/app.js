let currentSlide = 0;
const totalSlide = 3;
const track = document.getElementById('carouselTrack');
const indicators = document.querySelectorAll('.indicator');
console.log(indicators);

function updateCarousel(){
    track.style.transform = `translateX(-${currentSlide * 100}%)`;
    indicators.forEach((indicator ,index)=>{
        indicator.classList.toggle('active' , index === currentSlide);
    })
}

function nextSlide(){
    currentSlide = (currentSlide + 1) % totalSlide;
    updateCarousel();
}

function prevSlide(index){
    currentSlide = index;
    updateCarousel();
}

function goToSlide(index){
    currentSlide = index;
    updateCarousel();
}

setInterval(nextSlide , 5000);
